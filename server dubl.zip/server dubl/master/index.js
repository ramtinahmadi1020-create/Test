const express = require('express');
const fs = require('fs');
const path = require('path');

// خواندن دستی .env
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    const envFile = fs.readFileSync(envPath, 'utf8');
    envFile.split('\n').forEach(line => {
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) process.env[match[1].trim()] = match[2].trim();
    });
}

const app = express();
app.use(express.json());
const PORT = process.env.SERVER_PORT || 3000;

// تنظیمات اختیاری
const USE_DB = process.env.USE_DB === 'true';
const DB_URL = process.env.DB_URL || '';
const USE_CACHE = process.env.USE_CACHE === 'true';
const CACHE_URL = process.env.CACHE_URL || '';
const ALLOW_MASTER_FALLBACK = process.env.ALLOW_MASTER_FALLBACK === 'true';

const taskQueue = [];
const pendingWorkers = [];
const pendingClients = {};

// تابع کمکی برای ارتباط با دیتابیس و حافظه
async function callApi(url, method, body) {
    if (!url) return null;
    try {
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: body ? JSON.stringify(body) : undefined
        });
        return await response.json();
    } catch (err) {
        console.error(`[Master] Error calling ${url}:`, err.message);
        return null;
    }
}

function processLocally(task) {
    return new Promise((resolve) => {
        console.log(`[Master] ⚠️ Processing locally (Fallback Mode)`);
        let sum = 0;
        const num = task.payload.number || 50;
        for (let i = 0; i < num * 1000000; i++) { sum += i; }
        resolve(`نتیجه از خود مستر (فال‌بک): ${sum}`);
    });
}

async function distributeTask(taskType, payload) {
    return new Promise(async (resolve, reject) => {
        const taskId = Date.now().toString() + Math.random().toString(36).substring(7);
        const task = { id: taskId, type: taskType, payload };

        // 1. ذخیره در دیتابیس
        if (USE_DB && DB_URL) {
            const dbRes = await callApi(`${DB_URL}/save`, 'POST', { taskId, taskType, payload });
            if (dbRes && dbRes.error) return reject(new Error('Database Error! Task rejected.'));
        }

        // 2. ذخیره در کش
        if (USE_CACHE && CACHE_URL) {
            await callApi(`${CACHE_URL}/set`, 'POST', { key: taskId, value: 'processing', ttl: 3600 });
        }

        pendingClients[taskId] = { 
            resolve, reject, timer: setTimeout(() => {
                delete pendingClients[taskId];
                reject(new Error('Timeout: No response.'));
            }, 60000) 
        };

        // 3. توزیع
        if (pendingWorkers.length > 0) {
            const workerRes = pendingWorkers.shift();
            workerRes.json(task);
        } else if (ALLOW_MASTER_FALLBACK) {
            processLocally(task).then(result => {
                if (pendingClients[taskId]) {
                    clearTimeout(pendingClients[taskId].timer);
                    pendingClients[taskId].resolve(result);
                    delete pendingClients[taskId];
                    if (USE_DB && DB_URL) callApi(`${DB_URL}/update`, 'POST', { taskId, result });
                }
            });
        } else {
            taskQueue.push(task);
        }
    });
}

app.get('/api/task', (req, res) => {
    if (taskQueue.length > 0) {
        const task = taskQueue.shift();
        res.json(task);
    } else {
        pendingWorkers.push(res);
        setTimeout(() => {
            const index = pendingWorkers.indexOf(res);
            if (index !== -1) { pendingWorkers.splice(index, 1); res.status(204).end(); }
        }, 30000);
    }
});

app.post('/api/result', async (req, res) => {
    const { taskId, data } = req.body;
    if (USE_DB && DB_URL) await callApi(`${DB_URL}/update`, 'POST', { taskId, result: data });
    if (USE_CACHE && CACHE_URL) await callApi(`${CACHE_URL}/set`, 'POST', { key: taskId, value: data });

    if (pendingClients[taskId]) {
        clearTimeout(pendingClients[taskId].timer);
        pendingClients[taskId].resolve(data);
        delete pendingClients[taskId];
    }
    res.send('OK');
});

app.get('/api/do-heavy-work', async (req, res) => {
    try {
        const result = await distributeTask('heavy-math', { number: 50 });
        res.json({ success: true, result });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

app.use(express.static(path.join(__dirname, 'public')));
app.listen(PORT, () => console.log(`[Master] 🚀 Running on ${PORT}. Fallback: ${ALLOW_MASTER_FALLBACK}`));