const express = require('express');
const fs = require('fs');
const path = require('path');

// خواندن دستی .env
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    const envFile = fs.readFileSync(envPath, 'utf8');
    envFile.split('\n').forEach(line => {
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) process.env[match[1].trim()] = match[2].trim();
    });
}

const app = express();
app.use(express.json());
const PORT = process.env.SERVER_PORT || 5000;

const memoryCache = new Map();

app.post('/set', (req, res) => {
    const { key, value, ttl } = req.body;
    memoryCache.set(key, value);
    if (ttl) {
        setTimeout(() => memoryCache.delete(key), ttl * 1000);
    }
    res.json({ success: true });
});

app.get('/get/:key', (req, res) => {
    const value = memoryCache.get(req.params.key);
    if (value !== undefined) {
        res.json({ success: true, value });
    } else {
        res.status(404).json({ success: false, error: 'Not found' });
    }
});

app.listen(PORT, () => console.log(`[Cache Server] Running on port ${PORT}`));