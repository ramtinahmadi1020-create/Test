const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// خواندن دستی .env
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    const envFile = fs.readFileSync(envPath, 'utf8');
    envFile.split('\n').forEach(line => {
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) process.env[match[1].trim()] = match[2].trim();
    });
}

const app = express();
app.use(express.json());
const PORT = process.env.SERVER_PORT || 4000;

const db = new sqlite3.Database('./database.sqlite');

// ساخت جدول در اولین اجرا
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS tasks (
        taskId TEXT PRIMARY KEY,
        taskType TEXT,
        payload TEXT,
        status TEXT DEFAULT 'pending',
        result TEXT,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
});

app.post('/save', (req, res) => {
    const { taskId, taskType, payload } = req.body;
    db.run(`INSERT INTO tasks (taskId, taskType, payload, status) VALUES (?, ?, ?, 'processing')`,
        [taskId, taskType, JSON.stringify(payload)],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ success: true });
        }
    );
});

app.post('/update', (req, res) => {
    const { taskId, result } = req.body;
    db.run(`UPDATE tasks SET status = 'completed', result = ? WHERE taskId = ?`,
        [result, taskId],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ success: true });
        }
    );
});

app.listen(PORT, () => console.log(`[DB Server] SQLite running on port ${PORT}`));