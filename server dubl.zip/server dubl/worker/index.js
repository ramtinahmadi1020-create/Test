const http = require('http');
const https = require('https');
const { URL } = require('url');
const fs = require('fs');
const path = require('path');

// خواندن دستی .env
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    const envFile = fs.readFileSync(envPath, 'utf8');
    envFile.split('\n').forEach(line => {
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) process.env[match[1].trim()] = match[2].trim();
    });
}

const MASTER_URL = process.env.MASTER_URL;
if (!MASTER_URL) {
    console.error("CRITICAL ERROR: MASTER_URL is not set!");
    process.exit(1);
}

const heavyTasks = {
    'heavy-math': (payload) => {
        let sum = 0;
        const num = payload.number || 50;
        for (let i = 0; i < num * 1000000; i++) { sum += i; }
        return `نتیجه از ورکر: ${sum}`;
    }
};

function pollForTask() {
    const masterUrl = new URL('/api/task', MASTER_URL);
    const client = masterUrl.protocol === 'https:' ? https : http;

    const req = client.request(masterUrl, { method: 'GET' }, (res) => {
        if (res.statusCode === 204) {
            setTimeout(pollForTask, 100);
            return;
        }
        if (res.statusCode === 200) {
            let data = '';
            res.on('data', chunk => { data += chunk; });
            res.on('end', () => {
                try {
                    const task = JSON.parse(data);
                    console.log(`[Worker] Task received: ${task.id}`);
                    const resultOutput = heavyTasks[task.type] ? heavyTasks[task.type](task.payload) : "Unknown Task";
                    sendResult(task.id, resultOutput);
                } catch (e) { console.error(e.message); }
                pollForTask();
            });
        }
    });
    req.on('error', (err) => { console.error(err.message); setTimeout(pollForTask, 5000); });
    req.end();
}

function sendResult(taskId, data) {
    const resultUrl = new URL('/api/result', MASTER_URL);
    const client = resultUrl.protocol === 'https:' ? https : http;
    const postData = JSON.stringify({ taskId, data });
    
    const req = client.request(resultUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData) }
    }, (res) => res.resume());

    req.on('error', (err) => console.error(err.message));
    req.write(postData);
    req.end();
}

console.log(`[Worker] Started. Connecting to ${MASTER_URL}`);
pollForTask();